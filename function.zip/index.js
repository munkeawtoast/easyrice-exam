var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined")
    return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});

// apps/api/src/index.ts
import Fastify from "fastify";

// apps/api/src/app/plugins/sensible.ts
import fp from "fastify-plugin";
import sensible from "@fastify/sensible";
var sensible_default = fp(async function(fastify) {
  fastify.register(sensible);
});

// libs/models/src/dto/history.dto.ts
import { z as z2 } from "zod";

// libs/models/src/dto/standard.dto.ts
import { z } from "zod";

// libs/models/src/standard.ts
var InspectionSamplingPointConditions = /* @__PURE__ */ ((InspectionSamplingPointConditions2) => {
  InspectionSamplingPointConditions2["GE"] = "GE";
  InspectionSamplingPointConditions2["LE"] = "LE";
  InspectionSamplingPointConditions2["GT"] = "GT";
  InspectionSamplingPointConditions2["LT"] = "LT";
  InspectionSamplingPointConditions2["EQ"] = "EQ";
  InspectionSamplingPointConditions2["NE"] = "NE";
  return InspectionSamplingPointConditions2;
})(InspectionSamplingPointConditions || {});

// libs/models/src/dto/standard.dto.ts
var SubStandardSchemaDto = z.object({
  key: z.string(),
  minLength: z.number().nonnegative(),
  maxLength: z.number().nonnegative(),
  shape: z.array(z.string()),
  name: z.string(),
  conditionMin: z.nativeEnum(InspectionSamplingPointConditions),
  conditionMax: z.nativeEnum(InspectionSamplingPointConditions)
});
var StandardSchemaDto = z.object({
  name: z.string(),
  id: z.string(),
  createDate: z.string().datetime().optional(),
  standardName: z.string(),
  standardData: z.array(SubStandardSchemaDto)
});
var ListStandardResponseSchema = z.array(StandardSchemaDto);
var ListStandardApiSchema = {
  response: {
    200: ListStandardResponseSchema
  }
};

// libs/models/src/dto/history.dto.ts
var HistorySubStandardSchemaDto = SubStandardSchemaDto.merge(
  z2.object({
    value: z2.number()
  })
);
var HistoryDtoSchema = z2.object({
  name: z2.string().optional(),
  createDate: z2.string().optional(),
  inspectionID: z2.string(),
  standardID: z2.string(),
  note: z2.string().optional(),
  standardName: z2.string(),
  samplingDate: z2.string().datetime(),
  samplingPoint: z2.array(z2.string()),
  price: z2.number().optional()
});
var FullHistoryDtoSchema = HistoryDtoSchema.merge(
  z2.object({
    imageLink: z2.string().url(),
    standardData: z2.array(HistorySubStandardSchemaDto)
  })
);
var GetHistoryResponseSchema = FullHistoryDtoSchema;
var GetHistoryApiSchema = {
  params: z2.object({
    id: z2.string()
  }),
  response: {
    200: GetHistoryResponseSchema
  }
};
var ListHistoryResponseSchema = z2.object({
  data: z2.array(HistoryDtoSchema)
});
var ListHistoryApiSchema = {
  querystring: z2.object({
    fromDate: z2.string().datetime(),
    toDate: z2.string().datetime(),
    inspectionID: z2.string()
  }),
  response: {
    200: ListHistoryResponseSchema
  }
};
var DeleteHistoryApiSchema = {
  body: z2.object({
    inspectionID: z2.array(z2.string())
  }),
  response: {
    200: z2.string()
  }
};

// apps/api/src/app/routes/history.ts
import { z as z3 } from "zod";

// libs/database/src/dynamodb/rice-inspection-result.db.ts
import {
  DynamoDBDocumentClient,
  PutCommand,
  QueryCommand,
  GetCommand,
  TransactWriteCommand
} from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { randomUUID } from "crypto";
var RiceInspectionResultDatabase = class {
  constructor() {
    this.ddbTable = "easyrice-inspection_result";
    this.dynamodbClient = DynamoDBDocumentClient.from(new DynamoDBClient(), {
      marshallOptions: {
        removeUndefinedValues: true
      },
      unmarshallOptions: {}
    });
  }
  async query(query, options) {
    let condition = "type = :type";
    if (options.fromDate && options.toDate) {
      condition += " AND dateTime BETWEEN :fromDate AND :toDate";
    } else if (options.fromDate) {
      condition += " AND dateTime >= :fromDate";
    } else if (options.toDate) {
      condition += " AND dateTime <= :toDate";
    }
    const command = new QueryCommand({
      TableName: this.ddbTable,
      Limit: options?.limit ?? 50,
      ExpressionAttributeValues: {
        ":type": query.type,
        ":fromDate": options?.fromDate,
        ":toDate": options?.toDate
      },
      KeyConditionExpression: condition
    });
    const queryResult = await this.dynamodbClient.send(command);
    return queryResult.Items;
  }
  async create(item) {
    const command = new PutCommand({
      TableName: this.ddbTable,
      Item: {
        ...item,
        id: item.id ?? randomUUID()
      }
    });
    await this.dynamodbClient.send(command);
  }
  async get(query) {
    const command = new GetCommand({
      TableName: this.ddbTable,
      Key: {
        id: query.id,
        type: query.type
      }
    });
    const getResult = await this.dynamodbClient.send(command);
    return getResult.Item;
  }
  async bulkDelete(keys) {
    const command = new TransactWriteCommand({
      TransactItems: keys.map((key) => ({
        Delete: {
          TableName: this.ddbTable,
          Key: key
        }
      }))
    });
    await this.dynamodbClient.send(command);
  }
};
var ddbRiceInspectionResultDatabase = new RiceInspectionResultDatabase();

// libs/database/src/dynamodb/rice-standard.db.ts
import { DynamoDBDocumentClient as DynamoDBDocumentClient2, QueryCommand as QueryCommand2 } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient as DynamoDBClient2 } from "@aws-sdk/client-dynamodb";
var RiceStandardDatabase = class {
  constructor() {
    this.ddbTable = "easyrice-standard";
    this.dynamodbClient = DynamoDBDocumentClient2.from(new DynamoDBClient2(), {
      marshallOptions: {
        convertEmptyValues: true,
        removeUndefinedValues: true
      },
      unmarshallOptions: {}
    });
  }
  async query(keys, options) {
    const command = new QueryCommand2({
      TableName: this.ddbTable,
      Limit: options?.limit ?? 50,
      ExpressionAttributeValues: {
        ":type": { S: keys.type }
      },
      KeyConditionExpression: "type = :type"
    });
    const a = await this.dynamodbClient.send(command);
    return a.Items;
  }
};
var ddbRiceStandardDatabase = new RiceStandardDatabase();

// apps/api/src/app/services/rice-inspector.ts
var RiceInspectorService = class {
  constructor(riceInspectionResultDatabase = ddbRiceInspectionResultDatabase) {
    this.riceInspectionResultDatabase = riceInspectionResultDatabase;
    this.baseRiceKey = "whiterice";
  }
  transformToHistoryDto(record) {
    return {
      name: record.name,
      createDate: record.createDate,
      inspectionID: record.id,
      standardID: record.standardID,
      note: record.note,
      standardName: record.standardName,
      samplingDate: record.samplingDate,
      samplingPoint: record.samplingPoint
    };
  }
  transformToFullHistoryDto(record) {
    return {
      name: record.name,
      createDate: record.createDate,
      inspectionID: record.id,
      standardID: record.standardID,
      note: record.note,
      standardName: record.standardName,
      samplingDate: record.samplingDate,
      samplingPoint: record.samplingPoint,
      imageLink: record.imageLink,
      standardData: record.standardData
    };
  }
  async getRiceInspectionResult(query) {
    const record = await this.riceInspectionResultDatabase.get({
      id: query.id,
      type: this.baseRiceKey
    });
    return this.transformToFullHistoryDto(record);
  }
  async queryRiceInspectionResult(options) {
    const records = await this.riceInspectionResultDatabase.query(
      {
        type: this.baseRiceKey
      },
      {
        ...options,
        limit: 50
      }
    );
    return records.map(this.transformToHistoryDto);
  }
  async createRiceInspectionResult(item) {
    return this.riceInspectionResultDatabase.create({
      name: item.name ?? "",
      createDate: item.createDate,
      id: item.inspectionID,
      standardID: item.standardID,
      note: item.note,
      standardName: item.standardName,
      samplingDate: item.samplingDate,
      samplingPoint: item.samplingPoint,
      imageLink: item.imageLink,
      standardData: item.standardData,
      type: this.baseRiceKey
    });
  }
  async deleteRiceInspectionResult(ids) {
    return this.riceInspectionResultDatabase.bulkDelete(
      ids.map((id) => ({ id, type: this.baseRiceKey }))
    );
  }
};

// apps/api/src/app/routes/history.ts
async function history_default(fastify) {
  const riceInspectorService = new RiceInspectorService();
  fastify.withTypeProvider().register(
    (route) => {
      route.route({
        method: "GET",
        url: "/",
        schema: ListHistoryApiSchema,
        handler: async (request, reply) => {
          const result = [];
          if (request.query.inspectionID) {
            const {
              standardData: _,
              imageLink: __,
              ...record
            } = await riceInspectorService.getRiceInspectionResult({
              id: request.query.inspectionID
            });
            if (!record.createDate || record.createDate < request.query.fromDate || record.createDate > request.query.toDate) {
            } else {
              result.push(record);
            }
          } else {
            const records = await riceInspectorService.queryRiceInspectionResult({
              fromDate: request.query.fromDate,
              toDate: request.query.toDate
            });
            result.push(...records);
          }
          return reply.code(200).send({ data: result });
        }
      });
      route.route({
        method: "GET",
        url: "/:id",
        schema: GetHistoryApiSchema,
        handler: async (request, reply) => {
          const record = await riceInspectorService.getRiceInspectionResult({
            id: request.params.id
          });
          return reply.code(200).send(record);
        }
      });
      route.route({
        method: "POST",
        url: "/",
        schema: {
          body: GetHistoryResponseSchema,
          response: {
            200: GetHistoryResponseSchema
          }
        },
        handler: async (request, reply) => {
          await riceInspectorService.createRiceInspectionResult(request.body);
          return reply.code(201).send(request.body);
        }
      });
      route.route({
        method: "DELETE",
        url: "/",
        schema: {
          body: z3.object({
            inspectionID: z3.array(z3.string())
          }),
          response: {
            200: z3.string()
          }
        },
        handler: async (request, reply) => {
          await riceInspectorService.deleteRiceInspectionResult(
            request.body.inspectionID
          );
          return reply.code(200).send("success");
        }
      });
    },
    { prefix: "/history" }
  );
}

// apps/api/src/app/services/standard.ts
var StandardService = class {
  constructor(riceStandardDatabase = ddbRiceStandardDatabase) {
    this.riceStandardDatabase = riceStandardDatabase;
    this.baseRiceKey = "whiterice";
  }
  transformToStandardDto(record) {
    return {
      name: record.name,
      id: record.id,
      createDate: record.createDate,
      standardName: record.standardName,
      standardData: record.standardData
    };
  }
  async queryRiceInspectionResult(options) {
    const records = await this.riceStandardDatabase.query(
      {
        type: this.baseRiceKey
      },
      {
        ...options,
        limit: options?.limit ?? 50
      }
    );
    return records.map(this.transformToStandardDto);
  }
};

// apps/api/src/app/routes/standard.ts
async function standard_default(fastify) {
  const standardService = new StandardService();
  fastify.withTypeProvider().register(
    (instance) => {
      instance.route({
        method: "GET",
        url: "/",
        schema: ListStandardApiSchema,
        handler: (request, reply) => {
          const result = standardService.queryRiceInspectionResult();
          return reply.code(200).send(result);
        }
      });
    },
    { prefix: "/standard" }
  );
}

// apps/api/src/app/app.ts
import {
  serializerCompiler,
  validatorCompiler
} from "fastify-type-provider-zod";
async function app(fastify, opts) {
  fastify.setValidatorCompiler(validatorCompiler);
  fastify.setSerializerCompiler(serializerCompiler);
  fastify.register(sensible_default);
  fastify.register(history_default);
  fastify.register(standard_default);
}

// apps/api/src/index.ts
import { awsLambdaFastify } from "@fastify/aws-lambda";
var host = process.env.HOST ?? "localhost";
var port = process.env.PORT ? Number(process.env.PORT) : 3e3;
var server = Fastify({
  logger: true,
  ignoreTrailingSlash: true
});
var handler;
server.register(app);
if (__require.main === module) {
  server.listen({ port, host }, (err) => {
    if (err) {
      server.log.error(err);
      process.exit(1);
    } else {
      console.log(`[ ready ] http://${host}:${port}`);
    }
  });
} else {
  handler = awsLambdaFastify(server);
}
export {
  handler
};
